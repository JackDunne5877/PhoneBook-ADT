public interface PhbIterator{
	
  boolean hasNext();

  Person next();
  
  void reset();
  
  void deletePrev();
  
}