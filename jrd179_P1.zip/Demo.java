public class Demo{
 
	
	/**
	 * method to remove any duplicated people in two phonebooks.
	 * @param phb1
	 * @param phb2
	 * worst case runtime is O(log(n)) - function grows smaller and smaller as it is run more and as more duplicates
	 * are removed.
	 */
  public static void removeDuplicates(PhoneBook phb1, PhoneBook phb2){
   Person placeHolder;
   if(phb1.hasNext()) {
    placeHolder = phb1.next();
    phb2.reset();
    while(phb2.hasNext()) {
     if(placeHolder.equals(phb2.next())) {
      phb2.deletePrev();
     }
    }
    removeDuplicates(phb1, phb2);
   }
   else {
    phb1.reset();
   }
  }
  
  public static void main(String[] args) {
   Person p1 = new Person("Jack", "123456");
   Person p2 = new Person("Jeff", "324324");
   Person p3 = new Person("Jackie", "567567");
   Person p4 = new Person("Jeremy", "252252");
   Person p5 = new Person("Jack", "123456");
   Person p6 = new Person("Julie", "6756767");
   
   PhBLinkedList LLlist = new PhBLinkedList(p1);
   //insert elements at the first available spot, as the the insert function starts at the beginning of the list
   //and loops through. Starting at the front reduces the run time.
   LLlist.insert(1, p2);
   LLlist.insert(2, p3);
   
   
   PhBArrayList ArrList = new PhBArrayList(p4, 3);
   //insert the elements in the last available spot, as the insert function starts at the end of the array and
   //works backwards. This reduces the runtime because there is less parsing through the list to be done.
   ArrList.insert(3, p5);
   ArrList.insert(2, p6);
 
   System.out.print("this is the original LL phonebook");
   System.out.print(LLlist);
   
   removeDuplicates(LLlist, ArrList);
   
   System.out.print("this is the updated ArrList without the duplicates");
   System.out.print(ArrList);
   
   
  }
}