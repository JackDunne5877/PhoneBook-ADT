
public class PhBArrayList extends PhoneBook {

 private Person[] PhbArray;
 
 public PhBArrayList(Person person, int size) {
  Person[] PhbArray = new Person[size];
  PhbArray[0] = person;
 }
 
 
 /**returns the size of the array
  * worst case run time is O(n), as the length of the list grows
  * linearly, the runtime grows linearly
  */
 public int size() {
  return PhbArray.length;
 }
 
 /**tells us whether a person is in the array or not 
  * worst case run time is O(c) - run time is constant
  */
 public Person lookup(int i) {
  if(0 <= i && i <= PhbArray.length) {
   return PhbArray[i];
  }
  else {
   return null;
  }
 }
 
 /**
  * when a PhbArrayList is at maximum capacity, this function is
  * called to double the size of the array
  * worst case run time is O(n) - linear growth
  * @param ogArray - original array that is being grown
  * @return
  */
 public Person[] growList(Person[] ogArray) {
	 Person[] placeHolder = new Person[ogArray.length];
	 Person[] PhbArray = new Person[ogArray.length*2];
	 for(int i = 0; i < placeHolder.length; i++) {
		 PhbArray[i] = placeHolder[i];
	 }
	 return PhbArray;
 }
 
 /**
  * This function inserts a person into a given position(i) of the PhbArray
  * worst case run time is O(2n) - in the case of a PhbArray being full, the function calls growList(O(n)),
  * and then performs its insertion function(O(n)). The combination of these times is O(2n).
  */
 public void insert(int i, Person person) {
	 if(PhbArray[size()] == null) {  
		 PhbArray[i] = person;
		 if(i < PhbArray.length) {
		  for(int index = PhbArray.length - 1; index > i; index--) {
			 PhbArray[index] = PhbArray[i-1];
		   }
		   PhbArray[i] = person;
		  }
		  else {
		   PhbArray[PhbArray.length - 1] = person;
		  }
	 } 
	 else {
	  growList(PhbArray);
	 }
  }
 

 /**
  * This function removes a person from PhbArray.
  * its worst case runtime is O(c).
  */
 public Person remove(int i) {
  if(0 <= i && i <= PhbArray.length) {
   return null;
  }
  else {
   Person placeHolder = PhbArray[i];
   PhbArray[i] = null;
   return placeHolder;
  } 
 }

 @Override
 public void deletePrev() {}

 @Override
 public void reset() {}
}
