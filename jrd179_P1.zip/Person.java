/**
 * 
 */

/**
 * @author jack
 *
 */
public class Person {
	/**
	 * variables to hold a each person's name and phone number
	 */
	String personName;
	String phoneNumber;
	
	//constructor for an instance of a person
	public Person(String personID, String phoneNum) {
		personName = personID;
		phoneNumber = phoneNum;
	}

	public String getNumber() {
		return phoneNumber;
	}
	
	public String getName() {
		return personName;
	}
	
	public boolean equals(Person person) {
		if(getNumber() == person.getNumber() && getName() == person.getName()) {
			return true;
		}
		else {
			;
		}
		return false;
	}
}
