/**
 * 
 */

/**
 * @author jack
 *
 */
public abstract class PhoneBook implements PhbIterator {
	
	public abstract int size();
	
	public abstract Person lookup(int i);
	
	public abstract void insert(int i, Person person);
	
	public abstract Person remove(int i);
	
	private int counter = 0; //keeps track of the index of PhbIterator

	public Person next() {
		if(lookup(counter) != null) {
			Person placeHolder = lookup(counter);
			counter++;
			return placeHolder;
		}
		return null;
	}
	
	public boolean hasNext() {
		if(lookup(counter) != null) {
			return true;
		}
		return false;
	}
	
	public void deletePrev() {
		if(counter > 0) {
			remove(counter - 1);
		}
		else {
			System.out.print("previous node does not exist");
		}
	}
	
	public void reset() {
		counter = 0;
	}
}
