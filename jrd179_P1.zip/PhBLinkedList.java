
public class PhBLinkedList extends PhoneBook {
   
 //constructor
 public PhBLinkedList(Person person) {
  setFront(new LLNode(person, null));
  //frontNode.setNext(next);
 }

 /** the first node of the list */
   private LLNode frontNode;
   
   /** Returns the first node. */
   protected LLNode getFront() {
     return frontNode;
   }

   /**
    * Changes the first node of the list.
    * @param person  becomes the first node of the new list.
    */
   protected void setFront(LLNode node) {
     this.frontNode = node;
   }

   /** Adds an element to the front of the list */
   public void addToFront(Person person) {
     setFront(new LLNode(person, getFront()));
   }
   
   
   /**
    * Returns the length of the list
    * @return the quantity(length) of nodes in the list
    * worst case run time is O(n) - linear growth.
    */
   public int size() {
     int lengthSoFar = 0;
     LLNode nodeptr = getFront();
     while (nodeptr != null) {
       lengthSoFar++;
       nodeptr = nodeptr.getNext();
     }
     return lengthSoFar;
   }
   
   /**
    * This function inserts a person into the list.
    * worst case run time is O(2n) - this is caused by the two for loops within the function. Since they are not
    * nested, their run times add on to each other, rather than multiply.
    */
   public void insert(int i, Person person) {
    LLNode currentNode = getFront();
    //do for situations when i = 0 or length of list
    if(i == 0) {
     this.frontNode = new LLNode(person,currentNode.getNext());
    }
    else if(i == this.size()) {
     for(int index = 0; index < i - 1; index++) {
      currentNode = currentNode.getNext();
     }
     //makes new node, sets its next to i, sets i-1 = to new node
     LLNode node = new LLNode(person, null);
     currentNode.setNext(node);
    }
    for(int index = 0; index < i - 1; index++) {
     currentNode = currentNode.getNext();
    }
    //makes new node, sets its next to i, sets i-1 = to new node
    LLNode node = new LLNode(person, currentNode.getNext());
    node.setNext(currentNode.getNext());
    currentNode.setNext(node);
   }
   
   /**
    * Deletes the first occurrence of a person in the list.
    * If the person is not in the list, the list is unchanged.
    * @param person the person to remove
    * worst case run time is O(n) - linear.
    */
  public Person remove(int i) {
      LLNode placeHolder = this.frontNode;
      LLNode next;
      int counter = 0;
      while(placeHolder != null && counter < i - 1) {
       placeHolder = placeHolder.getNext();
       counter += 1;
      }
      if(placeHolder != null) {
       next = placeHolder.getNext();
       placeHolder.setNext(placeHolder.getNext().getNext());
       return next.getElement();
      }
      else {
       return null;
      }
  }
   
    /**
     * Determines whether a person is stored in the list
     * @param i the index to search for in the list and return the person at that index
     * @return person if and only if the parameter person is in the list
     * worst case run time is O(n) - linear.
     */
    public Person lookup(int i)   {
     LLNode placeHolder = frontNode;
     int counter = 0;
     while(placeHolder != null && counter < i){
       placeHolder = placeHolder.getNext();
       counter++;
     }
     if(placeHolder != null){
       return placeHolder.getElement();
     }
     return null;
   }

 @Override
 public void deletePrev() {
  // TODO Auto-generated method stub
  
 }

 @Override
 public void reset() {}
}
